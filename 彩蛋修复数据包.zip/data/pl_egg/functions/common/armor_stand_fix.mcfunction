# 备份原 HandItems
data modify entity @s ArmorItems[2] set from entity @s HandItems[0]
data modify entity @s ArmorItems[3] set from entity @s HandItems[1]
# ArmorItems 物品移入 HandItems
data modify entity @s HandItems[0] set from entity @s ArmorItems[0]
data modify entity @s HandItems[1] set from entity @s ArmorItems[1]
# 原 HandItems 物品移入 ArmorItems
data modify entity @s ArmorItems[0] set from entity @s ArmorItems[2]
data modify entity @s ArmorItems[1] set from entity @s ArmorItems[3]
# 清除备份
data modify entity @s ArmorItems[2] set value {}
data modify entity @s ArmorItems[3] set value {}