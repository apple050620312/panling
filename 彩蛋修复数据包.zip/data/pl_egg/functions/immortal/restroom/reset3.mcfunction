execute if entity @a[x=3159,y=35,z=936,dx=11,dy=16,dz=6] run schedule function pl_egg:immortal/restroom/reset3 20

# 区块 197, 58 已由梦盘加载 (forceload add 3163 936 3162 931)
# 关闭秘密房间
execute unless entity @a[x=3159,y=35,z=936,dx=11,dy=16,dz=6] run setblock 3157 34 935 minecraft:redstone_wire