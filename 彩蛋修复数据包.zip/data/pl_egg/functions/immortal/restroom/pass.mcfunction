tellraw @a[distance=..6] [{"text": "所有挑战成功完成", "color": "green"}, {"text": " 可以再次挑战休息室，并再次获得奖励", "color": "white"}, {"text": "\n某处秘密房间在 5 分钟内敞开, 尽快找下在哪~", "color": "gray"}]
advancement revoke @a[distance=..6] from pl_egg:immortal/restroom/status

# 重置机关
function pl_egg:immortal/restroom/reset1

# 准备重置结算房间
schedule function pl_egg:immortal/restroom/reset2 600

# 定时打开秘密房间
setblock 3157 34 935 minecraft:air
schedule function pl_egg:immortal/restroom/reset3 6000
