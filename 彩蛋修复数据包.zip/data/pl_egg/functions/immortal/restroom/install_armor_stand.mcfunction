execute unless entity @s[tag=fixed] run function pl_egg:common/armor_stand_fix
data modify entity @s Tags append value "fixed"
data modify entity @s ArmorItems[2] set value {id: "minecraft:diamond_chestplate", tag: {Damage: 0}, Count: 1b}
data modify entity @s ArmorItems[3] set value {id: "minecraft:player_head", Count: 1b}