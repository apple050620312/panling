# 跑酷入口
	execute if block 3184 11 952 minecraft:comparator[powered=false] run setblock 3181 12 949 minecraft:redstone_block
	setblock 3181 12 949 minecraft:air
# 秘密小房
	# 入口
		execute if block 3184 11 938 minecraft:comparator[powered=false] run setblock 3183 12 940 minecraft:redstone_block
		setblock 3183 12 940 minecraft:air
	# 通道
		execute if block 3145 9 942 minecraft:comparator[powered=false] run setblock 3143 10 945 minecraft:redstone_block
		setblock 3143 10 945 minecraft:air
	# 浴室
		setblock 3155 10 936 minecraft:air
		setblock 3155 10 936 minecraft:lever[face=wall,facing=east,powered=false]
# 迷宫入口
	setblock 3178 7 935 minecraft:air
	setblock 3178 7 935 minecraft:lever[face=wall,facing=east,powered=false]
# 射箭场开关
	# setblock 3177 9 954 minecraft:air
	# setblock 3177 9 954 minecraft:lever[face=wall,facing=west,powered=false]
