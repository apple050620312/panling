# 跑酷 (199,58)
	forceload add 3198 935
	data modify block 3198 27 935 Items set value []
	function pl_egg:immortal/restroom/chest/run
	forceload remove 3198 935
# 种族会议室
	# 箱子 (202,60)
		forceload add 3236 964
		data modify block 3236 19 964 Items set value []
		function pl_egg:immortal/restroom/chest/meeting
		forceload remove 3236 964
	# 盔甲架
		forceload add 3224 960
		execute as @e[type=armor_stand,x=3224.50,y=18.00,z=960.50,distance=..1] run function pl_egg:immortal/restroom/install_armor_stand
		forceload remove 3224 960
# 区块 197, 58 已由梦盘加载 (forceload add 3163 936 3162 931)
# 秘密小房间
	data modify block 3163 10 936 Items set value []
	function pl_egg:immortal/restroom/chest/secret
# 迷宫
	data modify block 3162 9 931 Items set value []
	function pl_egg:immortal/restroom/chest/maze
# 全通过检测
	setblock 3158 32 936 minecraft:redstone_wall_torch[facing=east]
	setblock 3159 32 936 minecraft:command_block
	data modify block 3159 32 936 Command set value "execute positioned 3166 30 941 run function pl_egg:immortal/restroom/pass"
say 仙族休息室修复完成