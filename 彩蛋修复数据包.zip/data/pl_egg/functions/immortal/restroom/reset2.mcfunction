execute if entity @a[x=3166,y=30,z=941,distance=..6] run schedule function pl_egg:immortal/restroom/reset2 20

execute positioned 3166 30 941 if entity @a[distance=..6] run return 0

# 关卡漏斗
forceload add 3165 945
data modify block 3165 30 945 Items set value [{Count:18b,Slot:0b,id:"minecraft:lime_wool",tag:{RepairCost:2,display:{Name:'{"text":"完成仙族跑酷"}'}}},{Count:1b,Slot:1b,id:"minecraft:lime_wool",tag:{RepairCost:2,display:{Name:'{"text":"完成仙族跑酷"}'}}},{Count:1b,Slot:2b,id:"minecraft:lime_wool",tag:{RepairCost:2,display:{Name:'{"text":"完成仙族跑酷"}'}}},{Count:1b,Slot:3b,id:"minecraft:lime_wool",tag:{RepairCost:2,display:{Name:'{"text":"完成仙族跑酷"}'}}},{Count:1b,Slot:4b,id:"minecraft:lime_wool",tag:{RepairCost:2,display:{Name:'{"text":"完成仙族跑酷"}'}}}]
forceload remove 3165 945
# 区块 197, 58 已由梦盘加载 (forceload add 3163 936 3162 931)
data modify block 3162 30 943 Items set value [{Count:18b,Slot:0b,id:"minecraft:yellow_wool",tag:{RepairCost:2,display:{Name:'{"text":"找到秘密小房間"}'}}},{Count:1b,Slot:1b,id:"minecraft:yellow_wool",tag:{RepairCost:2,display:{Name:'{"text":"找到秘密小房間"}'}}},{Count:1b,Slot:2b,id:"minecraft:yellow_wool",tag:{RepairCost:2,display:{Name:'{"text":"找到秘密小房間"}'}}},{Count:1b,Slot:3b,id:"minecraft:yellow_wool",tag:{RepairCost:2,display:{Name:'{"text":"找到秘密小房間"}'}}},{Count:1b,Slot:4b,id:"minecraft:yellow_wool",tag:{RepairCost:2,display:{Name:'{"text":"找到秘密小房間"}'}}}]
data modify block 3162 30 939 Items set value [{Count:18b,Slot:0b,id:"minecraft:black_wool",tag:{RepairCost:2,display:{Name:'{"text":"找到種族會議室"}'}}},{Count:1b,Slot:1b,id:"minecraft:black_wool",tag:{RepairCost:2,display:{Name:'{"text":"找到種族會議室"}'}}},{Count:1b,Slot:2b,id:"minecraft:black_wool",tag:{RepairCost:2,display:{Name:'{"text":"找到種族會議室"}'}}},{Count:1b,Slot:3b,id:"minecraft:black_wool",tag:{RepairCost:2,display:{Name:'{"text":"找到種族會議室"}'}}},{Count:1b,Slot:4b,id:"minecraft:black_wool",tag:{RepairCost:2,display:{Name:'{"text":"找到種族會議室"}'}}}]
data modify block 3165 30 937 Items set value [{Count:18b,Slot:0b,id:"minecraft:light_blue_wool",tag:{RepairCost:2,display:{Name:'{"text":"完成仙族迷宮"}'}}},{Count:1b,Slot:1b,id:"minecraft:light_blue_wool",tag:{RepairCost:2,display:{Name:'{"text":"完成仙族迷宮"}'}}},{Count:1b,Slot:2b,id:"minecraft:light_blue_wool",tag:{RepairCost:2,display:{Name:'{"text":"完成仙族迷宮"}'}}},{Count:1b,Slot:3b,id:"minecraft:light_blue_wool",tag:{RepairCost:2,display:{Name:'{"text":"完成仙族迷宮"}'}}},{Count:1b,Slot:4b,id:"minecraft:light_blue_wool",tag:{RepairCost:2,display:{Name:'{"text":"完成仙族迷宮"}'}}}]

# 关闭结算房间
forceload add 3232 965
setblock 3232 19 965 minecraft:redstone_torch
setblock 3232 19 965 minecraft:lever[face=floor,facing=west,powered=true]
forceload remove 3232 965
