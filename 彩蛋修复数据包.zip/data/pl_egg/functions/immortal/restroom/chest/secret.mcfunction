# 领取
execute positioned 3163 10 936 unless data block ~ ~ ~ Items[{Slot: 0b}] run loot replace block ~ ~ ~ container.0 loot pld:items/gold_ingot
execute positioned 3163 10 936 unless data block ~ ~ ~ Items[{Slot: 1b}] run loot replace block ~ ~ ~ container.1 loot pld:items/copper_cash
execute positioned 3163 10 936 unless data block ~ ~ ~ Items[{Slot: 7b}] run loot replace block ~ ~ ~ container.7 loot pld:items/copper_cash
execute positioned 3163 10 936 unless data block ~ ~ ~ Items[{Slot: 8b}] run loot replace block ~ ~ ~ container.8 loot pld:items/gold_ingot
execute positioned 3163 10 936 unless data block ~ ~ ~ Items[{Slot: 9b}] run loot replace block ~ ~ ~ container.9 loot pld:items/gold_ingot
execute positioned 3163 10 936 unless data block ~ ~ ~ Items[{Slot: 11b}] run loot replace block ~ ~ ~ container.11 loot pld:items/copper_cash
execute positioned 3163 10 936 unless data block ~ ~ ~ Items[{Slot: 15b}] run loot replace block ~ ~ ~ container.15 loot pld:items/copper_cash
execute positioned 3163 10 936 unless data block ~ ~ ~ Items[{Slot: 17b}] run loot replace block ~ ~ ~ container.17 loot pld:items/gold_ingot
execute positioned 3163 10 936 unless data block ~ ~ ~ Items[{Slot: 18b}] run loot replace block ~ ~ ~ container.18 loot pld:items/gold_ingot
execute positioned 3163 10 936 unless data block ~ ~ ~ Items[{Slot: 21b}] run loot replace block ~ ~ ~ container.21 loot pld:items/copper_cash
execute positioned 3163 10 936 unless data block ~ ~ ~ Items[{Slot: 22b}] run data modify block ~ ~ ~ Items append value {Slot: 22b, Count: 1b, id: "minecraft:yellow_wool", tag: {RepairCost: 2, display: {Name: '{"text":"找到秘密小房間"}'}}}
execute positioned 3163 10 936 unless data block ~ ~ ~ Items[{Slot: 23b}] run loot replace block ~ ~ ~ container.23 loot pld:items/copper_cash
execute positioned 3163 10 936 unless data block ~ ~ ~ Items[{Slot: 26b}] run loot replace block ~ ~ ~ container.26 loot pld:items/gold_ingot
