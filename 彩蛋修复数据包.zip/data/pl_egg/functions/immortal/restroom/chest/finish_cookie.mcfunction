# 允许下次再领取
advancement revoke @s only pl_egg:immortal/restroom/chest/finish_cookie

# 领取
execute positioned 3167 45 942 unless data block ~ ~ ~ Items[{Slot: 13b}] run data modify block ~ ~ ~ Items append value {Slot: 13b, Count: 1b, id: "minecraft:cookie", tag: {RepairCost: 2, display: {Name: '{"text":"米琪的餅乾"}'}}}
