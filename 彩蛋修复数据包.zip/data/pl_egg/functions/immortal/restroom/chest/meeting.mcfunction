# 领取
execute positioned 3236 19 964 unless data block ~ ~ ~ Items[{Slot: 0b}] run loot replace block ~ ~ ~ container.0 loot pld:items/gold_ingot
execute positioned 3236 19 964 unless data block ~ ~ ~ Items[{Slot: 8b}] run loot replace block ~ ~ ~ container.8 loot pld:items/gold_ingot
execute positioned 3236 19 964 unless data block ~ ~ ~ Items[{Slot: 9b}] run loot replace block ~ ~ ~ container.9 loot pld:items/gold_ingot
execute positioned 3236 19 964 unless data block ~ ~ ~ Items[{Slot: 10b}] run loot replace block ~ ~ ~ container.10 loot pld:items/copper_cash
execute positioned 3236 19 964 unless data block ~ ~ ~ Items[{Slot: 11b}] run loot replace block ~ ~ ~ container.11 loot pld:items/copper_cash
execute positioned 3236 19 964 unless data block ~ ~ ~ Items[{Slot: 12b}] run loot replace block ~ ~ ~ container.12 loot pld:items/copper_cash
execute positioned 3236 19 964 unless data block ~ ~ ~ Items[{Slot: 13b}] run data modify block ~ ~ ~ Items append value {Slot: 13b, Count: 1b, id: "minecraft:black_wool", tag: {RepairCost: 2, display: {Name: '{"text":"找到種族會議室"}'}}}
execute positioned 3236 19 964 unless data block ~ ~ ~ Items[{Slot: 14b}] run loot replace block ~ ~ ~ container.14 loot pld:items/copper_cash
execute positioned 3236 19 964 unless data block ~ ~ ~ Items[{Slot: 15b}] run loot replace block ~ ~ ~ container.15 loot pld:items/copper_cash
execute positioned 3236 19 964 unless data block ~ ~ ~ Items[{Slot: 16b}] run loot replace block ~ ~ ~ container.16 loot pld:items/copper_cash
execute positioned 3236 19 964 unless data block ~ ~ ~ Items[{Slot: 17b}] run loot replace block ~ ~ ~ container.17 loot pld:items/gold_ingot
execute positioned 3236 19 964 unless data block ~ ~ ~ Items[{Slot: 18b}] run loot replace block ~ ~ ~ container.18 loot pld:items/gold_ingot
execute positioned 3236 19 964 unless data block ~ ~ ~ Items[{Slot: 26b}] run loot replace block ~ ~ ~ container.26 loot pld:items/gold_ingot
