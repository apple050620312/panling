# 允许下次再领取
advancement revoke @s only pl_egg:immortal/restroom/chest/finish_apple

# 领取
execute positioned 3170 45 939 unless data block ~ ~ ~ Items[{Slot: 13b}] run data modify block ~ ~ ~ Items append value {Slot: 13b, Count: 1b, id: "minecraft:apple", tag: {RepairCost: 2, display: {Name: '{"text":"Ken將的蘋果"}'}}}
