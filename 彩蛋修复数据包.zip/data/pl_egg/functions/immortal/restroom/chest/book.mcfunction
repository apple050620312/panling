# 允许下次再领取
advancement revoke @s only pl_egg:immortal/restroom/chest/book

# 领取
execute positioned 3177 15 942 unless data block ~ ~ ~ Items[{Slot: 0b}] run data modify block ~ ~ ~ Items append value {Slot: 0b, Count: 1b, id: "minecraft:written_book", tag: {pages: ['{"text":"安安尼好我是阿瀨喔喔喔"}'], title: "呵呵ww", author: "NOOAO", resolved: 1b}}
