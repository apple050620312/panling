# 允许下次再领取
advancement revoke @s only pl_egg:immortal/restroom/chest/fish

# 领取
execute positioned 3177 17 942 unless data block ~ ~ ~ Items[{Slot: 24b}] run data modify block ~ ~ ~ Items append value {Slot: 24b, Count: 1b, id: "minecraft:cod", tag: {RepairCost: 2, display: {Name: '{"text":"無糖貓的生魚"}'}}}
