# 允许下次再领取
advancement revoke @s only pl_egg:immortal/restroom/chest/finish_fish

# 领取
execute positioned 3167 45 936 unless data block ~ ~ ~ Items[{Slot: 13b}] run data modify block ~ ~ ~ Items append value {Slot: 13b, Count: 1b, id: "minecraft:cod", tag: {RepairCost: 2, display: {Name: '{"text":"無糖貓的生魚"}'}}}
