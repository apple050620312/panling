#皇宫守卫
	#入口西
	forceload add 170 2 172 2
	data modify block 172 44 2 Command set value "function pl_egg:middle/palace/npc/guard"
	execute positioned 172 44 2 run function pl_egg:middle/palace/npc/guard
	forceload remove 170 2 172 2
	#入口东
	forceload add 186 2 188 2
	data modify block 188 44 2 Command set value "function pl_egg:middle/palace/npc/guard"
	execute positioned 188 44 2 run function pl_egg:middle/palace/npc/guard
	forceload remove 186 2 188 2
	#广场西南
	forceload add 169 -40 171 -40
	data modify block 171 45 -40 Command set value "function pl_egg:middle/palace/npc/guard"
	execute positioned 171 45 -40 run function pl_egg:middle/palace/npc/guard
	forceload remove 169 -40 171 -40
	#广场东南
	forceload add 187 -40 189 -40
	data modify block 189 45 -40 Command set value "function pl_egg:middle/palace/npc/guard"
	execute positioned 189 45 -40 run function pl_egg:middle/palace/npc/guard
	forceload remove 187 -40 189 -40
	#广场中西
	forceload add 169 -66 171 -66
	data modify block 171 45 -66 Command set value "function pl_egg:middle/palace/npc/guard"
	execute positioned 171 45 -66 run function pl_egg:middle/palace/npc/guard
	forceload remove 169 -66 171 -66
	#广场中东
	forceload add 187 -66 189 -66
	data modify block 189 45 -66 Command set value "function pl_egg:middle/palace/npc/guard"
	execute positioned 189 45 -66 run function pl_egg:middle/palace/npc/guard
	forceload remove 187 -66 189 -66
	#广场西南
	forceload add 169 -85 171 -85
	data modify block 171 45 -85 Command set value "function pl_egg:middle/palace/npc/guard"
	execute positioned 171 45 -85 run function pl_egg:middle/palace/npc/guard
	forceload remove 169 -85 171 -85
	#广场东南
	forceload add 187 -85 189 -85
	data modify block 189 45 -85 Command set value "function pl_egg:middle/palace/npc/guard"
	execute positioned 189 45 -85 run function pl_egg:middle/palace/npc/guard
	forceload remove 187 -85 189 -85
	#大门西
	forceload add 170 -132 172 -140
	data modify block 172 62 -132 Command set value "function pl_egg:middle/palace/npc/guard"
	execute positioned 172 62 -132 run function pl_egg:middle/palace/npc/guard
	data modify block 172 62 -140 Command set value "function pl_egg:middle/palace/npc/guard"
	execute positioned 172 62 -140 run function pl_egg:middle/palace/npc/guard
	forceload remove 170 -132 172 -140
	#大门东
	forceload add 186 -132 188 -140
	data modify block 188 62 -132 Command set value "function pl_egg:middle/palace/npc/guard"
	execute positioned 188 62 -132 run function pl_egg:middle/palace/npc/guard
	data modify block 188 62 -140 Command set value "function pl_egg:middle/palace/npc/guard"
	execute positioned 188 62 -140 run function pl_egg:middle/palace/npc/guard
	forceload remove 186 -132 188 -140
#皇帝私藏物
	forceload add 177 -168 181 -167
	setblock 181 67 -167 minecraft:air
	setblock 181 67 -168 minecraft:sticky_piston[extended=true,facing=south]
	data modify block 177 67 -168 Command set value "execute if block ~1 ~ ~ minecraft:comparator[powered=false]"
	forceload remove 177 -168 181 -167
say 皇宫彩蛋修复完成