tellraw @a [{"text":"皇城公告：","color":"light_purple"},{"text":"大膽竊賊潛入皇宮，偷竊皇帝內帑被發現。軒轅氏震怒之下處其死刑！","color":"light_purple"}]
function pl_egg:middle/palace/thief/damage