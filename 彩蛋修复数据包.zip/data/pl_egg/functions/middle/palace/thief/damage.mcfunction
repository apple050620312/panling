advancement revoke @a[x=181,y=67,z=-165,distance=30..] from pl_egg:middle/palace/chest/private
effect give @a[advancements={pl_egg:middle/palace/chest/private=true}] minecraft:instant_damage 2 100
# 持续伤害，直到窃贼离开
execute if entity @a[advancements={pl_egg:middle/palace/chest/private=true}] run schedule function pl_egg:middle/palace/thief/damage 4