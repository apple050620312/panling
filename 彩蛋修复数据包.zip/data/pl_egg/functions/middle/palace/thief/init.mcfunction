function pl_egg:middle/palace/chest/private
# 合上
data merge block 177 67 -168 {SuccessCount:0}

tellraw @a[x=181,y=67,z=-165,distance=..30] [{"text":"軒轅氏：","color":"aqua"},{"text":"大膽刁民，敢偷朕的內帑！拖下去，斬！","color":"white"}]
schedule function pl_egg:middle/palace/thief/delay 10