#防止盔甲架被钓竿移动
	forceload add 69 172 69 161
	execute as @e[type=armor_stand,x=69.50,y=46.00,z=161.50,distance=..1] run data modify entity @s NoGravity set value 1b
	execute as @e[type=armor_stand,x=69.50,y=46.00,z=172.50,distance=..1] run data modify entity @s NoGravity set value 1b
	forceload remove 69 172 69 161
	forceload add 82 183
	execute as @e[type=armor_stand,x=82.50,y=46.00,z=183.50,distance=..1] run data modify entity @s NoGravity set value 1b
	forceload remove 82 183
	forceload add 83 171
	execute as @e[type=armor_stand,x=83.50,y=46.00,z=171.50,distance=..1] run data modify entity @s NoGravity set value 1b
	forceload remove 83 171
say 皇城西杂货摊修复完成