tellraw @a [{"text":"鳳花樓公告：","color":"light_purple"},{"selector":"@s","color":"yellow"},{"text":"進入了鳳花樓廂房，但是因為身上帶的錢不夠所以被鳳娘一個過肩摔扔出了鳳花樓......","color":"light_purple"}]

effect give @s minecraft:nausea 8 0
effect give @s minecraft:weakness 1800 7
scoreboard players set @s egg_cyanFun -360
function pl_egg:middle/cyan/floor/particle

tellraw @s [{"text":"你失去了一些元寶，獲得了虛弱效果，將在30分鐘後復原......當然，前提是你還活著=w=","color":"gray"}]
execute at @s run playsound entity.enderman.death ambient @s
tellraw @a [{"text":"鳳娘：","color":"aqua"},{"text":"哎呀這位客官，身上盤纏不夠，就別來樓裡耍大爺了唄？","color":"white"}]

schedule function pl_egg:middle/cyan/floor/into_fail_delay 20
