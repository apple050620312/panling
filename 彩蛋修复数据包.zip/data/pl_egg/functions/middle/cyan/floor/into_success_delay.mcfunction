tellraw @a[scores={egg_cyanClearIngot=3..}] [{"text":"你失去了一些元寶，獲得了虛弱效果，將在30分鐘後復原","color":"gray"}]
execute as @a[scores={egg_cyanClearIngot=3..}] run tellraw @a [{"text":"溫存過後，","color":"light_purple"},{"selector":"@s","color":"yellow"},{"text":"被索取了一些打賞，腳步虛浮的離開了鳳花樓......等等，這時間好像有點短？","color":"light_purple"}]

effect give @a[scores={egg_cyanClearIngot=3..}] minecraft:weakness 1800 7
scoreboard players set @a[scores={egg_cyanClearIngot=3..}] egg_cyanFun 360
function pl_egg:middle/cyan/floor/particle

tp @a[scores={egg_cyanClearIngot=3..}] 56 49 34
scoreboard players reset @a[scores={egg_cyanClearIngot=3..}] egg_cyanClearIngot
