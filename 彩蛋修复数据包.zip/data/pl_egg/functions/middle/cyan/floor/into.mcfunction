tp @s 57 16 23
execute store result score @s egg_cyanClearIngot run clear @s minecraft:gold_ingot{id: "panling:gold_ingot"} 3
#元宝不足
execute if score @s egg_cyanClearIngot matches 0..2 run function pl_egg:middle/cyan/floor/into_fail
#元宝足够
execute if score @s egg_cyanClearIngot matches 3.. run function pl_egg:middle/cyan/floor/into_success