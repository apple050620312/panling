effect give @s minecraft:blindness 15 0
effect give @s minecraft:nausea 15 0
tellraw @a [{"text":"鳳花樓公告：","color":"light_purple"},{"selector":"@s","color":"yellow"},{"text":"進入了鳳花樓廂房，和裡頭的小姐和小倌們度過了愉快時光","color":"light_purple"}]
schedule function pl_egg:middle/cyan/floor/into_success_delay 100