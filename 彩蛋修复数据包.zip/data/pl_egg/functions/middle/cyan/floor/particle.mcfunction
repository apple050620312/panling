execute as @a[scores={egg_cyanFun=..-1}] at @s run particle minecraft:angry_villager ~ ~2 ~ 1 0 1 1 10 force
scoreboard players add @a[scores={egg_cyanFun=..-1}] egg_cyanFun 1

execute as @a[scores={egg_cyanFun=1..}] at @s run particle minecraft:heart ~ ~2 ~ 1 0 1 1 10 force
scoreboard players remove @a[scores={egg_cyanFun=1..}] egg_cyanFun 1

# 清除已经用尽的残留次数标记
scoreboard players reset @a[scores={egg_cyanFun=0}] egg_cyanFun
# 持续间隔运行，直到所有玩家次数用尽
execute if entity @a[scores={egg_cyanFun=-2147483648..2147483647}] run schedule function pl_egg:middle/cyan/floor/particle 100
