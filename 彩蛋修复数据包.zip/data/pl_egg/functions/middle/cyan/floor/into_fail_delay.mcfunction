effect give @a[scores={egg_cyanClearIngot=0..2}] minecraft:instant_damage 2 6
schedule function pl_egg:middle/cyan/floor/into_fail_delay2 20