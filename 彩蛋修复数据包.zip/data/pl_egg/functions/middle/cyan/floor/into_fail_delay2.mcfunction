tp @a[scores={egg_cyanClearIngot=0..2},x=57,y=15,z=23,distance=..2] 56 49 34
scoreboard players reset @a[scores={egg_cyanClearIngot=0..2}] egg_cyanClearIngot