# 扣取元宝统计
	scoreboard objectives add egg_cyanClearIngot dummy
# 出房粒子
	scoreboard objectives add egg_cyanFun dummy
forceload add 53 18 60 32
# 音效修复
	data modify block 57 45 32 Command set value "playsound block.iron_door.open ambient @p 57 7 30 3"
	data modify block 56 4 32 Command set value "playsound block.iron_door.open ambient @p 56 48 34 3"
# 盔甲架会话
	execute as @e[type=armor_stand,x=58.50,y=7.00,z=18.50,distance=..1] run data modify entity @s NoGravity set value 1b
	data modify block 57 3 22 Command set value 'tellraw @a[x=58,y=6,z=19,distance=..3] [{"text":"軀線大濕-阿城：","color":"dark_red"},{"text":"好小子!對人體軀線抱持著好奇的態度就對了!跟著我以後包你吃香喝辣!!","color":"white"}]'
# 厢房入口检测
	setblock 63 7 22 minecraft:redstone_wire
	data modify block 62 6 19 Command set value "execute if block 63 6 19 comparator[powered=false]"
# 二层房间入口
	setblock 53 17 23 minecraft:stone_pressure_plate
	setblock 54 17 23 minecraft:stone_pressure_plate
	data modify block 56 15 24 Command set value "execute positioned 54 17 23 as @p[distance=..2] run function pl_egg:middle/cyan/floor/into"
forceload remove 53 18 60 31
# 厢房NPC
	forceload add 57 0 57 1
	execute positioned 57 7 0 run function pl_egg:middle/cyan/npc/behind
	data modify block 57 2 1 Command set value "execute positioned ~ ~4.5 ~-1 run function pl_egg:middle/cyan/npc/behind"
	forceload remove 57 0 57 1
say 凤花楼彩蛋修复完成