# 允许下次再领取
advancement revoke @s only pl_egg:middle/cyan/chest/key

# 领取
execute positioned 60 7 20 unless data block ~ ~ ~ Items[{Slot: 13b}] run data modify block ~ ~ ~ Items append value {Slot: 13b, Count: 1b, id: "minecraft:tripwire_hook", tag: {RepairCost: 3, display: {Name: '{"text":"石玖大爺廂房的鑰匙"}'}}}
