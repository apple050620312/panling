# 领取
execute positioned 60 7 16 unless data block ~ ~ ~ Items[{Slot: 26b}] run loot replace block ~ ~ ~ container.26 loot pld:items/silver_ticket
