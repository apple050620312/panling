#恢复大厅入口
	forceload add 229 -141
	setblock 229 49 -141 minecraft:cobblestone_stairs[facing=north,half=bottom,shape=straight,waterlogged=false]
	forceload remove 229 -141
#入口盔甲架
	forceload add 224 -149 237 -147
	execute as @e[type=armor_stand,x=224.50,y=48.00,z=-146.50,distance=..1] run data merge entity @s {NoGravity: 1b, Invulnerable: 1b, ArmorItems: [{id: "minecraft:leather_boots", tag: {display: {color: 10075109}, Damage: 0}, Count: 1b}, {id: "minecraft:leather_leggings", tag: {display: {color: 4408131}, Damage: 0}, Count: 1b}, {id: "minecraft:leather_chestplate", tag: {display: {color: 4408131}, Damage: 0}, Count: 1b}, {id: "minecraft:player_head", tag: {SkullOwner: {Id: [I; 260497508, -338736586, -1333673891, -1422241753], Properties: {textures: [{Value: "eyJ0aW1lc3RhbXAiOjE0MjY2ODcxMjA4OTYsInByb2ZpbGVJZCI6ImJhODQyNmFmNGRmNzQyOWVhMGIzNjg2M2QxZWZlNjI0IiwicHJvZmlsZU5hbWUiOiJLWTZlYXIiLCJpc1B1YmxpYyI6dHJ1ZSwidGV4dHVyZXMiOnsiU0tJTiI6eyJ1cmwiOiJodHRwOi8vdGV4dHVyZXMubWluZWNyYWZ0Lm5ldC90ZXh0dXJlLzYxOTMxMjk5NWZhMjg5YjQ1M2JkZmVlYTY0ZDQ5MTRkZTk5YTc2M2I4Yzc0MGVlYTI5MmIzMmJmZTRhNTFjIn19fQ=="}]}}}, Count: 1b}], HandItems: [{id: "minecraft:melon_slice", Count: 1b}, {}]}
	execute as @e[type=armor_stand,x=237.50,y=48.00,z=-148.50,distance=..1] run data merge entity @s {NoGravity: 1b, Invulnerable: 1b, ArmorItems: [{id: "minecraft:iron_boots", tag: {Damage: 0}, Count: 1b}, {id: "minecraft:leather_leggings", tag: {display: {color: 6645093}, Damage: 0}, Count: 1b},  {id: "minecraft:leather_chestplate", tag: {display: {color: 4482494}, Damage: 0}, Count: 1b}, {id: "minecraft:player_head", tag: {SkullOwner: {Id: [I;-1873297533,1118391855,-1658532747,-1023620691], Properties: {textures: [{Value: "eyJ0aW1lc3RhbXAiOjE0MjkxMDc3Mzg3MzIsInByb2ZpbGVJZCI6IjkwNTdiZjgzNDJhOTRlMmY5ZDI0Y2M3NWMyZmNjOWFkIiwicHJvZmlsZU5hbWUiOiJLaXJkeV8iLCJpc1B1YmxpYyI6dHJ1ZSwidGV4dHVyZXMiOnsiU0tJTiI6eyJ1cmwiOiJodHRwOi8vdGV4dHVyZXMubWluZWNyYWZ0Lm5ldC90ZXh0dXJlLzZlZjIwZWY0NDdjMzE0YTczNmEyNjUwOWE1OWY1MjIyZTZhM2Q1Y2U2ODI0ZDU1ZTVjOWNiZDBmMzNlNzAifX19"}]}}}, Count: 1b}], HandItems: []}
	forceload remove 224 -149 237 -147
#酒保NPC
	forceload add 257 -166 259 -154
	data modify block 258 43 -166 Command set value "execute positioned ~ ~4.5 ~ run function pl_egg:middle/hall/npc/barman"
	execute positioned 258 48 -166 run function pl_egg:middle/hall/npc/barman
	data modify block 258 43 -160 Command set value "execute positioned ~ ~4.5 ~ run function pl_egg:middle/hall/npc/barman"
	execute positioned 258 48 -160 run function pl_egg:middle/hall/npc/barman
	data modify block 258 43 -154 Command set value "execute positioned ~ ~4.5 ~ run function pl_egg:middle/hall/npc/barman"
	execute positioned 258 48 -154 run function pl_egg:middle/hall/npc/barman
#修复墙面
	# 暂不实装，因为此区域没有入口
	# forceload add 225 -198 225 -177
	# setblock 225 48 -198 minecraft:structure_block[mode=load]{ignoreEntities:1b,integrity:1.0f,metadata:"",mirror:"NONE",mode:"LOAD",name:"pl_egg:middle_hall_wall",posX:0,posY:1,posZ:0,powered:0b,rotation:"NONE",seed:0L,showair:0b,showboundingbox:1b,sizeX:3,sizeY:7,sizeZ:22}
	# setblock 225 49 -198 minecraft:redstone_block
	# setblock 226 50 -187 minecraft:redstone_lamp[lit=true]
	# forceload remove 225 -198 225 -177
#酒保NPC2
	forceload add 196 -142 196 -149
	data modify block 196 53 -144 Command set value "execute positioned ~ ~0.5 ~2 run function pl_egg:middle/hall/npc/barman"
	execute positioned 196 54 -142 run function pl_egg:middle/hall/npc/barman
	data modify block 196 53 -147 Command set value "execute positioned ~ ~0.5 ~-2 run function pl_egg:middle/hall/npc/barman"
	execute positioned 196 54 -149 run function pl_egg:middle/hall/npc/barman
	forceload remove 196 -142 196 -149
#角落盔甲架
	forceload add 196 -159 195 -160
	execute as @e[type=armor_stand,x=196.40,y=46.00,z=-159.00,distance=..1] run data merge entity @s {NoGravity: 1b, Invulnerable: 1b, ArmorItems: [{id: "minecraft:chainmail_boots", tag: {Damage: 0}, Count: 1b}, {id: "minecraft:chainmail_leggings", tag: {Damage: 0}, Count: 1b}, {id: "minecraft:chainmail_chestplate", tag: {Damage: 0}, Count: 1b}, {id: "minecraft:player_head", tag: {SkullOwner: {Name:"MRPPPPP", Id: [I;-1953028026,-856931226,-1240793240,-1598231354], Properties: {textures: [{Value: "eyJ0aW1lc3RhbXAiOjE0Mjc5NTAwNjUwNTIsInByb2ZpbGVJZCI6ImU3YjY1Y2RiYTg0NjQ1MDI4MTljZGI1MzdjMTZlYzUyIiwicHJvZmlsZU5hbWUiOiJNUlBQUFBQIiwidGV4dHVyZXMiOnsiU0tJTiI6eyJ1cmwiOiJodHRwOi8vdGV4dHVyZXMubWluZWNyYWZ0Lm5ldC90ZXh0dXJlL2NhYzRmZThjZTFlNWNjZWUxMDVmNmRhODMzNDJkMzQzZjlhMDQyMzg2YWIyZGYzMmRlNWY5NTRhMjFmYzkwNmMifX19"}]}}}, Count: 1b}], HandItems: []}
	forceload remove 196 -159 195 -160
#舞台盔甲架
	forceload add 151 -140 142 -155
	forceload add 196 -159 195 -160
	execute as @e[type=armor_stand,x=143.50,y=47.40,z=-153.50,distance=..1] run data merge entity @s {NoGravity: 1b, Invulnerable: 1b, ArmorItems: [{id: "minecraft:iron_boots", tag: {Damage: 0}, Count: 1b}, {id: "minecraft:leather_leggings", tag: {display: {color: 1644825}, Damage: 0}, Count: 1b}, {id: "minecraft:leather_chestplate", tag: {display: {color: 1644825}, Damage: 0}, Count: 1b}, {id: "minecraft:player_head", tag: {SkullOwner: {Name:"jerry40822", Id: [I;-1953028026,-856931226,-1240793240,-1598231354], Properties: {textures: [{Value: "eyJ0aW1lc3RhbXAiOjE0Mjc1NDY1NDgwMzcsInByb2ZpbGVJZCI6IjgzZjA0ZGUzYzZjOTRhZmZhNDA3NTI5YWI0YTQzN2Y3IiwicHJvZmlsZU5hbWUiOiJqZXJyeTQwODIyIiwiaXNQdWJsaWMiOnRydWUsInRleHR1cmVzIjp7IlNLSU4iOnsidXJsIjoiaHR0cDovL3RleHR1cmVzLm1pbmVjcmFmdC5uZXQvdGV4dHVyZS85NmExNGZkNWE4ZDA1MTkyZjk5ZjJmYzQxNDhhNTA1OTFkY2IwNjI2NGYzMzhhOWNhY2QyYzlhMGJhNzY4ZSJ9fX0="}]}}}, Count: 1b}], HandItems: [{id: "minecraft:lever", Count: 1b}, {}]}
	execute as @e[type=armor_stand,x=150.50,y=47.00,z=-144.50,distance=..1] run data merge entity @s {NoGravity: 1b, Invulnerable: 1b, ArmorItems: [{id: "minecraft:iron_boots", tag: {Damage: 0}, Count: 1b}, {id: "minecraft:leather_leggings", tag: {display: {color: 1644825}, Damage: 0}, Count: 1b}, {id: "minecraft:leather_chestplate", tag: {display: {color: 1644825}, Damage: 0}, Count: 1b}, {id: "minecraft:player_head", tag: {SkullOwner: {Name:"mizuokami", Id: [I;-1953028026,-856931226,-1240793240,-1598231354], Properties: {textures: [{Value: "eyJ0aW1lc3RhbXAiOjE0Mjc1ODQyMjA3MTgsInByb2ZpbGVJZCI6IjdlZTQ4N2FkYWRiYjQ1MDY4MTllOGViYTNiNWI1YmEwIiwicHJvZmlsZU5hbWUiOiJtaXp1b2thbWkiLCJpc1B1YmxpYyI6dHJ1ZSwidGV4dHVyZXMiOnsiU0tJTiI6eyJ1cmwiOiJodHRwOi8vdGV4dHVyZXMubWluZWNyYWZ0Lm5ldC90ZXh0dXJlLzkxNjhlNGZjYWRkMGEyZjc1ZTg0MzJiYWYwYjdkNGM0MTQyMDI4YjgxYzg0OWIzMzlkMTY5ODk4MThhYjhmZiJ9fX0="}]}}}, Count: 1b}], HandItems: []}
	execute as @e[type=armor_stand,x=146.50,y=47.40,z=-140.40,distance=..1] run data merge entity @s {NoGravity: 1b, Invulnerable: 1b, ArmorItems: [{id: "minecraft:iron_boots", tag: {Damage: 0}, Count: 1b}, {id: "minecraft:leather_leggings", tag: {display: {color: 1644825}, Damage: 0}, Count: 1b}, {id: "minecraft:leather_chestplate", tag: {display: {color: 1644825}, Damage: 0}, Count: 1b}, {id: "minecraft:player_head", tag: {SkullOwner: {Name:"Audiace0809", Id: [I;-1953028026,-856931226,-1240793240,-1598231354], Properties: {textures: [{Value: "eyJ0aW1lc3RhbXAiOjE0Mjc1ODM0MzMwMTQsInByb2ZpbGVJZCI6IjViYjE5ZjBjNDBjNjQzMmZhMGY0NTQyZDAzY2YzZGNjIiwicHJvZmlsZU5hbWUiOiJBdWRpYWNlMDgwOSIsInRleHR1cmVzIjp7IlNLSU4iOnsidXJsIjoiaHR0cDovL3RleHR1cmVzLm1pbmVjcmFmdC5uZXQvdGV4dHVyZS8yNmQ2MDhlOWE5YWQ5NmI4ODhjNjg0NzNmY2NlZWRkNWZjODQyNDhmNGIwNTc5YjhmYmU5YjVhYTM0NjZjIn19fQ=="}]}}}, Count: 1b}], HandItems: []}
	forceload remove 151 -140 142 -155
#最后延迟执行
	schedule function pl_egg:middle/hall/install_delay 10
say 皇城大厅彩蛋修复完成