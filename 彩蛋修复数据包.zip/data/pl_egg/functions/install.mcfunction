function pl_egg:middle/palace/install
function pl_egg:middle/hall/install
function pl_egg:middle/cyan/install
function pl_egg:middle/west_stall/install
function pl_egg:human/hostel/install
function pl_egg:immortal/restroom/install