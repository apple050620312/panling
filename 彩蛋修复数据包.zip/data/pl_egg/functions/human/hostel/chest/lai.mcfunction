# 允许下次再领取
advancement revoke @s only pl_egg:human/hostel/chest/lai

# 领取
execute positioned 1713 50 230 unless data block ~ ~ ~ Items[{Slot: 0b}] run data modify block ~ ~ ~ Items append value {Slot: 0b, Count: 1b, id: "minecraft:written_book", tag: {pages: ['{"text":"安安我是阿瀨\\n我是女的:3\\n\\n我是熊\\n我的寵物是拉姆\\n\\n偷偷告訴你\\n阿勳是色狼wwwww\\n\\n歡迎到仙族參觀\\n\\n藏經閣.太極3兄弟都是好景點\\n感謝您的支持  阿瀨"}'], title: "介紹書", author: "NOOAO", resolved: 1b}}
