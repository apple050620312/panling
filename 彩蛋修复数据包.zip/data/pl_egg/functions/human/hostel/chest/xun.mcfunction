# 允许下次再领取
advancement revoke @s only pl_egg:human/hostel/chest/xun

# 领取
execute positioned 1735 50 234 unless data block ~ ~ ~ Items[{Slot: 0b}] run data modify block ~ ~ ~ Items append value {Slot: 0b, Count: 1b, id: "minecraft:written_book", tag: {pages: ['{"text":"哈哈哈~大家好，我是阿勳經過超級無敵久的時間盤靈古域終於要蓋完了特別在封測前幾天跑到這邊偷偷的留下這本書，做個紀念"}', '{"text":"2年多的時間說長不長，說短不短，真的很感謝大家在這期間付出，沒有大家的努力，就沒有盤靈古域這張地圖，真的非常謝謝大家。                   阿勳 留                 2015/03/09"}', '{"text":""}', '{"text":""}', '{"text":""}', '{"text":""}', '{"text":""}', '{"text":""}', '{"text":""}', '{"text":""}', '{"text":""}', '{"text":""}', '{"text":""}', '{"text":"(書的最後一頁被撕毀了，無法繼續閱讀)"}'], title: "阿勳的日記", author: "z2007526", resolved: 1b}}
