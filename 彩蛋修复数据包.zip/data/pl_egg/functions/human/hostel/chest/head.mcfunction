# 允许下次再领取
advancement revoke @s only pl_egg:human/hostel/chest/head

# 领取
execute positioned 1748 51 210 unless data block ~ ~ ~ Items[{Slot: 11b}] run data modify block ~ ~ ~ Items append value {Slot: 11b, Count: 1b, id: "minecraft:written_book", tag: {pages: ['{"text":"這是 這棟房間\\n的主人的頭顱 ...."}'], title: "頭 ....", author: "milk0294", resolved: 1b}}
execute positioned 1748 51 210 unless data block ~ ~ ~ Items[{Slot: 13b}] run data modify block ~ ~ ~ Items append value {Slot: 13b, Count: 1b, id: "minecraft:player_head"}
