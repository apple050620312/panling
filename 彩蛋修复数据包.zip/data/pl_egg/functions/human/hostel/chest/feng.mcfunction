# 允许下次再领取
advancement revoke @s only pl_egg:human/hostel/chest/feng

# 领取
execute positioned 1746 50 220 unless data block ~ ~ ~ Items[{Slot: 0b}] run data modify block ~ ~ ~ Items append value {Slot: 0b, Count: 1b, id: "minecraft:written_book", tag: {pages: ['{"text":"我是小風    是個管理\\n\\n\\n\\n\\n爽~~~~~~~~~~~~~~~~~~~~\\n\\n\\n\\n\\n\\n\\n2013/3/1   小風"}'], title: "小風", author: "karta1983243", resolved: 1b}}
