# 允许下次再领取
advancement revoke @s only pl_egg:human/hostel/chest/yo

# 领取
execute positioned 1702 50 212 unless data block ~ ~ ~ Items[{Slot: 0b}] run data modify block ~ ~ ~ Items append value {Slot: 0b, Count: 1b, id: "minecraft:paper", tag: {RepairCost: 2, display: {Name: '{"text":"金紙BJ４"}'}}}
execute positioned 1702 50 212 unless data block ~ ~ ~ Items[{Slot: 4b}] run data modify block ~ ~ ~ Items append value {Slot: 4b, Count: 1b, id: "minecraft:paper", tag: {RepairCost: 2, display: {Name: '{"text":"金紙BJ４"}'}}}
execute positioned 1702 50 212 unless data block ~ ~ ~ Items[{Slot: 10b}] run data modify block ~ ~ ~ Items append value {Slot: 10b, Count: 1b, id: "minecraft:paper", tag: {RepairCost: 2, display: {Name: '{"text":"金紙BJ４"}'}}}
execute positioned 1702 50 212 unless data block ~ ~ ~ Items[{Slot: 12b}] run data modify block ~ ~ ~ Items append value {Slot: 12b, Count: 1b, id: "minecraft:paper", tag: {RepairCost: 2, display: {Name: '{"text":"金紙BJ４"}'}}}
execute positioned 1702 50 212 unless data block ~ ~ ~ Items[{Slot: 20b}] run data modify block ~ ~ ~ Items append value {Slot: 20b, Count: 1b, id: "minecraft:paper", tag: {RepairCost: 2, display: {Name: '{"text":"金紙BJ４"}'}}}
execute positioned 1702 50 212 unless data block ~ ~ ~ Items[{Slot: 24b}] run data modify block ~ ~ ~ Items append value {Slot: 24b, Count: 1b, id: "minecraft:paper", tag: {RepairCost: 2, display: {Name: '{"text":"金紙BJ４"}'}}}
execute positioned 1702 50 212 unless data block ~ ~ ~ Items[{Slot: 25b}] run data modify block ~ ~ ~ Items append value {Slot: 25b, Count: 1b, id: "minecraft:paper", tag: {RepairCost: 2, display: {Name: '{"text":"金紙BJ４"}'}}}
execute positioned 1703 50 212 unless data block ~ ~ ~ Items[{Slot: 2b}] run data modify block ~ ~ ~ Items append value {Slot: 2b, Count: 1b, id: "minecraft:paper", tag: {RepairCost: 2, display: {Name: '{"text":"金紙BJ４"}'}}}
execute positioned 1703 50 212 unless data block ~ ~ ~ Items[{Slot: 5b}] run data modify block ~ ~ ~ Items append value {Slot: 5b, Count: 1b, id: "minecraft:paper", tag: {RepairCost: 2, display: {Name: '{"text":"金紙BJ４"}'}}}
execute positioned 1703 50 212 unless data block ~ ~ ~ Items[{Slot: 8b}] run data modify block ~ ~ ~ Items append value {Slot: 8b, Count: 1b, id: "minecraft:paper", tag: {RepairCost: 2, display: {Name: '{"text":"金紙BJ４"}'}}}
execute positioned 1703 50 212 unless data block ~ ~ ~ Items[{Slot: 11b}] run data modify block ~ ~ ~ Items append value {Slot: 11b, Count: 1b, id: "minecraft:paper", tag: {RepairCost: 2, display: {Name: '{"text":"金紙BJ４"}'}}}
execute positioned 1703 50 212 unless data block ~ ~ ~ Items[{Slot: 14b}] run data modify block ~ ~ ~ Items append value {Slot: 14b, Count: 1b, id: "minecraft:paper", tag: {RepairCost: 2, display: {Name: '{"text":"金紙BJ４"}'}}}
execute positioned 1703 50 212 unless data block ~ ~ ~ Items[{Slot: 17b}] run data modify block ~ ~ ~ Items append value {Slot: 17b, Count: 1b, id: "minecraft:paper", tag: {RepairCost: 2, display: {Name: '{"text":"金紙BJ４"}'}}}
execute positioned 1703 50 212 unless data block ~ ~ ~ Items[{Slot: 20b}] run data modify block ~ ~ ~ Items append value {Slot: 20b, Count: 1b, id: "minecraft:paper", tag: {RepairCost: 2, display: {Name: '{"text":"金紙BJ４"}'}}}
execute positioned 1703 50 212 unless data block ~ ~ ~ Items[{Slot: 24b}] run data modify block ~ ~ ~ Items append value {Slot: 24b, Count: 1b, id: "minecraft:paper", tag: {RepairCost: 2, display: {Name: '{"text":"金紙BJ４"}'}}}
execute positioned 1703 50 212 unless data block ~ ~ ~ Items[{Slot: 25b}] run data modify block ~ ~ ~ Items append value {Slot: 25b, Count: 1b, id: "minecraft:paper", tag: {RepairCost: 2, display: {Name: '{"text":"金紙BJ４"}'}}}
