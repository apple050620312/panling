# 所有箱子物品和原盘相同，故不需要刷新

# 入口
	forceload add 1725 220
	data modify block 1725 154 220 Command set value "function pl_egg:human/hostel/into"
	forceload remove 1725 220
# 出口
	forceload add 1726 200
	data modify block 1726 40 200 Command set value "function pl_egg:human/hostel/leave"
	forceload remove 1726 200
# 阿勳
	# NPC
		forceload add 1734 230 1736 232
		data modify block 1734 48 230 Command set value "execute positioned ~2 ~1.5 ~2 run function pl_egg:human/hostel/npc/xun"
		execute positioned 1736 50 232 run function pl_egg:human/hostel/npc/xun
		forceload remove 1734 230 1736 232
	# 盔甲架
		# forceload add 1753 219
		# execute as @e[type=armor_stand,x=1753.82,y=35.00,z=219.50,distance=..10] run function pl_egg:common/armor_stand_fix
		# forceload remove 1753 219
say 人族诡异客栈修复完成