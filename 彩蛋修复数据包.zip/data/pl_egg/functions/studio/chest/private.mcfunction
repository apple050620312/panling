# 允许下次再领取
advancement revoke @s only pl_egg:studio/chest/private

# 领取
execute positioned 1358 91 516 unless data block ~ ~ ~ Items[{Slot: 0b}] run data modify block ~ ~ ~ Items append value {Slot: 0b, Count: 1b, id: "minecraft:mushroom_stew"}
execute positioned 1358 91 516 unless data block ~ ~ ~ Items[{Slot: 1b}] run data modify block ~ ~ ~ Items append value {Slot: 1b, Count: 64b, id: "minecraft:cooked_mutton"}
execute positioned 1358 91 516 unless data block ~ ~ ~ Items[{Slot: 2b}] run data modify block ~ ~ ~ Items append value {Slot: 2b, Count: 64b, id: "minecraft:cooked_salmon"}
execute positioned 1358 91 516 unless data block ~ ~ ~ Items[{Slot: 3b}] run data modify block ~ ~ ~ Items append value {Slot: 3b, Count: 64b, id: "minecraft:cooked_cod"}
execute positioned 1358 91 516 unless data block ~ ~ ~ Items[{Slot: 4b}] run data modify block ~ ~ ~ Items append value {Slot: 4b, Count: 64b, id: "minecraft:cooked_beef"}
execute positioned 1358 91 516 unless data block ~ ~ ~ Items[{Slot: 5b}] run data modify block ~ ~ ~ Items append value {Slot: 5b, Count: 64b, id: "minecraft:cooked_chicken"}
execute positioned 1358 91 516 unless data block ~ ~ ~ Items[{Slot: 6b}] run data modify block ~ ~ ~ Items append value {Slot: 6b, Count: 64b, id: "minecraft:cooked_porkchop"}
execute positioned 1358 91 516 unless data block ~ ~ ~ Items[{Slot: 7b}] run data modify block ~ ~ ~ Items append value {Slot: 7b, Count: 1b, id: "minecraft:mushroom_stew"}
execute positioned 1358 91 516 unless data block ~ ~ ~ Items[{Slot: 8b}] run data modify block ~ ~ ~ Items append value {Slot: 8b, Count: 1b, id: "minecraft:mushroom_stew"}
execute positioned 1358 91 516 unless data block ~ ~ ~ Items[{Slot: 9b}] run data modify block ~ ~ ~ Items append value {Slot: 9b, Count: 1b, id: "minecraft:cake"}
execute positioned 1358 91 516 unless data block ~ ~ ~ Items[{Slot: 10b}] run data modify block ~ ~ ~ Items append value {Slot: 10b, Count: 1b, id: "minecraft:cake"}
execute positioned 1358 91 516 unless data block ~ ~ ~ Items[{Slot: 11b}] run data modify block ~ ~ ~ Items append value {Slot: 11b, Count: 1b, id: "minecraft:cake"}
execute positioned 1358 91 516 unless data block ~ ~ ~ Items[{Slot: 12b}] run data modify block ~ ~ ~ Items append value {Slot: 12b, Count: 1b, id: "minecraft:cake"}
execute positioned 1358 91 516 unless data block ~ ~ ~ Items[{Slot: 13b}] run data modify block ~ ~ ~ Items append value {Slot: 13b, Count: 1b, id: "minecraft:cake"}
execute positioned 1358 91 516 unless data block ~ ~ ~ Items[{Slot: 14b}] run data modify block ~ ~ ~ Items append value {Slot: 14b, Count: 1b, id: "minecraft:cake"}
execute positioned 1358 91 516 unless data block ~ ~ ~ Items[{Slot: 15b}] run data modify block ~ ~ ~ Items append value {Slot: 15b, Count: 1b, id: "minecraft:cake"}
execute positioned 1358 91 516 unless data block ~ ~ ~ Items[{Slot: 16b}] run data modify block ~ ~ ~ Items append value {Slot: 16b, Count: 1b, id: "minecraft:cake"}
execute positioned 1358 91 516 unless data block ~ ~ ~ Items[{Slot: 17b}] run data modify block ~ ~ ~ Items append value {Slot: 17b, Count: 1b, id: "minecraft:cake"}
execute positioned 1358 91 516 unless data block ~ ~ ~ Items[{Slot: 18b}] run data modify block ~ ~ ~ Items append value {Slot: 18b, Count: 1b, id: "minecraft:mushroom_stew"}
execute positioned 1358 91 516 unless data block ~ ~ ~ Items[{Slot: 19b}] run data modify block ~ ~ ~ Items append value {Slot: 19b, Count: 64b, id: "minecraft:baked_potato"}
execute positioned 1358 91 516 unless data block ~ ~ ~ Items[{Slot: 20b}] run data modify block ~ ~ ~ Items append value {Slot: 20b, Count: 64b, id: "minecraft:melon_slice"}
execute positioned 1358 91 516 unless data block ~ ~ ~ Items[{Slot: 21b}] run data modify block ~ ~ ~ Items append value {Slot: 21b, Count: 64b, id: "minecraft:pufferfish"}
execute positioned 1358 91 516 unless data block ~ ~ ~ Items[{Slot: 22b}] run data modify block ~ ~ ~ Items append value {Slot: 22b, Count: 64b, id: "minecraft:apple"}
execute positioned 1358 91 516 unless data block ~ ~ ~ Items[{Slot: 23b}] run data modify block ~ ~ ~ Items append value {Slot: 23b, Count: 64b, id: "minecraft:pumpkin_pie"}
execute positioned 1358 91 516 unless data block ~ ~ ~ Items[{Slot: 24b}] run data modify block ~ ~ ~ Items append value {Slot: 24b, Count: 64b, id: "minecraft:bread"}
execute positioned 1358 91 516 unless data block ~ ~ ~ Items[{Slot: 25b}] run data modify block ~ ~ ~ Items append value {Slot: 25b, Count: 1b, id: "minecraft:mushroom_stew"}
execute positioned 1358 91 516 unless data block ~ ~ ~ Items[{Slot: 26b}] run data modify block ~ ~ ~ Items append value {Slot: 26b, Count: 1b, id: "minecraft:mushroom_stew"}
